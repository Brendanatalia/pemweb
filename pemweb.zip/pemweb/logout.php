<?php
require("db_connect.php");
session_start();
$user = $_SESSION['login_user'];
session_destroy();
header ("Location: project.php");

?>
