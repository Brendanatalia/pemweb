<?php
include 'db_connect.php';
$tipe = $_POST['tipe'];
$Merk = $_POST['Merk'];
$namabarang = $_POST['namabarang'];

$simpan="INSERT INTO barang VALUES('','$tipe','$Merk','$namabarang')";
$query = mysqli_query($connection, $simpan);
header("location:tampildata.php?pesan=input");
?>
