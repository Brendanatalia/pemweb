<html>
<head>
<link rel="stylesheet" type="text/css" href="project.css"/>
<title>Ubeaute</title>
</head>
<body> 

<ul>
  <li><a href="project.php">UBEAUTE</a></li>
  <li class="dropdown">
    <a class="drop2">Skincare</a>
    <div class="isidropdown">
      <a href="wardah.php">Wardah</a>
      <a href="vivasc.php">Viva</a>
      <a href="scmustika.php">Mustika Ratu</a>
    </div>
  </li>
  <li class="dropdown">
    <a class="drop2">Make Up</a>
    <div class="isidropdown">
      <a href="muwardah.php">Wardah</a>
      <a href="#">Viva</a>
      <a href="#">Mustika Ratu</a>
    </div>
  </li>
  <li style="float:right"><a href="login.php">Login</a></li>
  <li style="float:right"><img src="keranjang.png" height="30"></li>
</ul>

<center>
  <h1>UBEAUTE</h1>
  <h2>Be Beautiful, Be Indonesia</h2>
  <br><br><br>
  <table>
    <tr><td><h2>Skincare</h2></td></tr>
      <tr><td><h3><a href=" s"> Wardah </a></h3></td>
        <td><h3> <a href=" "> Viva </a></h3></td>
        <td><h3> <a href=""> Mustika Ratu </a></h3></td></tr>
      <tr><td><img src="wardah2.jpg" width="200px" height:"200px"></td><td><img src="viva.jpg" width="200px" height="200px"></td>
        <td><img src="mustikaratu.jpg" width="200px" height="200px"></td></tr>
    </table><br><br>
    <table>
      <tr><td><h2>Make Up</h2></td></tr>
      <tr><td><h3><a href=" "> Wardah </a></h3></td>
        <td><h3> <a href=" "> Viva </a></h3></td>
        <td><h3> <a href=""> Mustika Ratu </a></h3></td></tr>
        <tr><td><img src="wardah2.jpg" width="200px" height:"200px"></td><td><img src="viva.jpg" width="200px" height="200px"></td>
          <td><img src="mustikaratu.jpg" width="200px" height="200px"></td></tr>
        </table></center>
</body>
</html>
