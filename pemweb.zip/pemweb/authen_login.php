

<?php
require ('db_connect.php');
if(isset($_POST['username']) and isset($_POST['password'])){
	$username = $_POST['username'];
	$password = $_POST['password'];
	$query = "SELECT * FROM login WHERE username='$username' and password='$password'";

	$result = mysqli_query($connection, $query) or die(mysqli_error($connection));
	$count = mysqli_num_rows($result);

	if($count == 1){
		echo "<script type='text/javascript'>alert('Login Credentials verified')</script>";
		$result = mysqli_query($connection, $query) or die (mysqli_error($connection));
		session_start();
		$_SESSION['login_user']=$username;
		header("Location: halamanlogin.php");
	}else{
		echo "<script type='text/javascript'>alert('Invalid Login Credentials')</script>";
	}
}
?>

