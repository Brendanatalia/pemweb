<?php
include 'connections.php';

$id_product=$_POST['id_product'];
$rating="UPDATE 'products' SET 'rating' = '1' WHERE 'products'.'id_product' = $id_product";

$query=mysqli_query($koneksi, $rating);
header("location:products.php");
?>
