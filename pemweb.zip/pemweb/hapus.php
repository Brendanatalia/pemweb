<?php 

include 'input2.php';
 

$id = $_GET['id'];

mysqli_query($koneksi,"delete from barang where id='$id'");
 

header("location:tampildata.php");
 
?>
