<html>
<head>
	<link rel="stylesheet" type="text/css" href="project.css"/>
</head>
<body>
	<?php
	if(isset($_GET['pesan'])){
		$pesan = $_GET['pesan'];
		if($pesan == "input"){
			echo "Data berhasil di input.";
		}else if($pesan == "update"){
			echo "Data berhasil di update.";
		}else if($pesan == "hapus"){
			echo "Data berhasil di hapus.";
		}
	}
	?>
	<br/>
	<a class="tombol" href="inputdata.php"> <p align="center">+ Tambah Data Baru </p></a>

	<h3 align="center">Data user</h3>
	<table align="center" border="1" class="table">
		<tr>
			<th>No</th>
			<th>Tipe Barang</th>
			<th>Merk</th>
			<th>Nama Barang</th>
		</tr>
		<?php
		include "db_connect.php";
		$query_mysql = mysqli_query($connection, "SELECT * FROM barang")or die(mysqli_error());
		$nomor = 1;
		while($data = mysqli_fetch_array($query_mysql)){
		?>
		<tr>
			<td><?php echo $nomor++; ?></td>
			<td><?php echo $data['tipe']; ?></td>
			<td><?php echo $data['Merk']; ?></td>
			<td><?php echo $data['namabarang']; ?></td>
			<td>
				<a class="edit" href="edit.php?id=<?php echo $data['id']; ?>">Edit</a> |
				<a class="hapus" href="hapus.php?id=<?php echo $data['id']; ?>">Hapus</a>
			</td>
		</tr>
		<?php } ?>
	</table>
</body>
</html>
