<html>
<head>
<link rel="stylesheet" type="text/css" href="project.css"/>
<title>Welcome to Ubeaute</title>
</head>
<body>

<ul>
  <li><a href="project.php">UBEAUTE</a></li>
  <li class="dropdown">
    <a class="drop2">Skincare</a>
    <div class="isidropdown">
      <a href="wardah.php">Wardah </a>
      <a href="vivasc.php">Viva</a>
      <a href="scmustika.php">Mustika Ratu</a>
    </div>
  </li>
  <li class="dropdown">
    <a class="drop2">Make Up</a>
    <div class="isidropdown">
      <a href="muwardah.php">Wardah</a>
      <a href="vivamu.php">Viva</a>
      <a href="mustikamu.php">Mustika Ratu</a>
    </div>
  </li>
  <li style="float:right"><a href="logout.php">Logout</a></li>
  <li style="float:right"><img src="keranjang.png" height="30"></li>
</ul>

<center>
  <h1>UBEAUTE</h1>
  <h2>Be Beautiful, Be Indonesia</h2>
  <br><br><br>
  <table>
    <tr><td><h2>Skincare</h2></td></tr>
      
      <tr><td><h3><a href="wardah.php"> Wardah </a></h3></td>
        <td><h3> <a href="vivasc.php"> Viva </a></h3></td>
        <td><h3> <a href="scmustika.php"> Mustika Ratu </a></h3></td></tr>
      <tr><td><img src="wardah2.jpg" width="200px" height:"200px"></td><td><img src="viva.jpg" width="200px" height="200px"></td>
        <td><img src="mustikaratu.jpg" width="200px" height="200px"></td></tr>
    </table><br><br>
    <table>
       <tr><td><h2>Make Up</h2></td></tr>
      <tr><td><h3><a href="wardahmu.php"> Wardah </a></h3></td>
        <td><h3> <a href="vivamu.php"> Viva </a></h3></td>
        <td><h3> <a href="mustikamu.php"> Mustika Ratu </a></h3></td></tr>
        <tr><td><img src="wardah2.jpg" width="200px" height:"200px"></td><td><img src="viva.jpg" width="200px" height="200px"></td>
          <td><img src="mustikaratu.jpg" width="200px" height="200px"></td></tr>
        </table></center>
</body>
</html>
