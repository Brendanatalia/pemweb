<html>
<head>
</head>
<body>
	<a href="tampildata.php">Lihat Semua Data</a>

	<br/>
	<h3>Input data baru</h3>
	<form action="input2.php" method="post">
		<table>
			<tr>
				<td>Tipe Barang</td>
				<td><input type="text" name="tipe"></td>
			</tr>
			<tr>
				<td>Merk</td>
				<td><input type="text" name="Merk"></td>
			</tr>
			<tr>
				<td>Nama Barang</td>
				<td><input type="text" name="namabarang"></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" value="Simpan"></td>
			</tr>
		</table>
	</form>
</body>
</html>
