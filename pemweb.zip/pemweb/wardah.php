<html>
<head>
<link rel="stylesheet" type="text/css" href="project.css"/>
<link rel ="stylesheet" type ="text/css" href="style.css">
<link rel ="stylesheet" href ="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<title>Skincare Wardah</title>
</head>
<body>

<ul>
  <li><a href="project.php">UBEAUTE</a></li>
  <li class="dropdown">
    <a class="drop2">Skincare</a>
    <div class="isidropdown">
      <a href="wardah.php">Wardah </a>
      <a href="scmustika.php">Viva</a>
      <a href="vivasc.php">Mustika Ratu</a>
    </div>
  </li>
  <li class="dropdown">
    <a class="drop2">Make Up</a>
    <div class="isidropdown">
      <a href="muwardah.php">Wardah</a>
      <a href="vivamu.php">Viva</a>
      <a href="mustikamu.php">Mustika Ratu</a>
    </div>
  </li>
  <li style="float:right"><a href="logout.php">Logout</a></li>
  <li style="float:right"><img src="keranjang.png" height="30"></li>
</ul>

<center>
        <h1>UBEAUTE</h1> <br>
      <h2>Skincare by Wardah</h2>
      <p> <i> Inspiring Beauty </i></p>
      
    <br><br><br>
  
  <table>
  
      <tr>
        <td><img src="1wardah.jpg" width="200px" height:"200px"> <BR>
        <p align="center"> <b> Wardah Pore Tightening Toner</b></p> <br> 
         <fieldset class="rating">
    <input type="radio" id="star5" name="rating" value="5"/><label class = "full" for="star5" title="Awesome -  stars"></label>
    <input type="radio" id="star4" name="rating" value="4"/><label class = "full" for="star4" title="Pretty good -  stars"></label>
    <input type="radio" id="star3" name="rating" value="3"/><label class = "full" for="star3" title="Meh -  stars"></label>
    <input type="radio" id="star2" name="rating" value="2"/><label class = "full" for="star2" title="Kinda Bad -  stars"></label>
    <input type="radio" id="star1" name="rating" value="1"/><label class = "full" for="star1" title="Sucks big time -  stars"></label>
  </fieldset>
<br> <br>  
<button class="button"> submit </button> 
    
</td> 
         
         <td><img src="2wardah.jpg" width="200px" height:"200px"> <BR>
         <p align="center"> <b> Wardah Perfect Bright Moisturizer SPF </b></p> <br> 
         <fieldset class="rating">
    <input type="radio" id="star5" name="rating" value="5"/><label class = "full" for="star5" title="Awesome -  stars"></label>
    <input type="radio" id="star4" name="rating" value="4"/><label class = "full" for="star4" title="Pretty good -  stars"></label>
    <input type="radio" id="star3" name="rating" value="3"/><label class = "full" for="star3" title="Meh -  stars"></label>
    <input type="radio" id="star2" name="rating" value="2"/><label class = "full" for="star2" title="Kinda Bad -  stars"></label>
    <input type="radio" id="star1" name="rating" value="1"/><label class = "full" for="star1" title="Sucks big time -  stars"></label>
  </fieldset>
<br> <br>  
<button class="button"> submit </button> 
</td>
         <td><img src="3wardah.jpg" width="200px" height:"200px"> <BR>
         <p align="center"> <b> Wardah Perfect Bright Tone Up Cream</b></p> <br> 
         
         <fieldset class="rating">
    <input type="radio" id="star5" name="rating" value="5"/><label class = "full" for="star5" title="Awesome -  stars"></label>
    <input type="radio" id="star4" name="rating" value="4"/><label class = "full" for="star4" title="Pretty good -  stars"></label>
    <input type="radio" id="star3" name="rating" value="3"/><label class = "full" for="star3" title="Meh -  stars"></label>
    <input type="radio" id="star2" name="rating" value="2"/><label class = "full" for="star2" title="Kinda Bad -  stars"></label>
    <input type="radio" id="star1" name="rating" value="1"/><label class = "full" for="star1" title="Sucks big time -  stars"></label>
  </fieldset>
<br> <br>  
<button class="button"> submit </button> </td>

        <td><img src="4wardah.jpg" width="200px" height:"200px"> <BR>
        <p align="center"> <b> Wardah Acne Gentle Scrub</b></p> <br> 
        <fieldset class="rating">
    <input type="radio" id="star5" name="rating" value="5"/><label class = "full" for="star5" title="Awesome -  stars"></label>
    <input type="radio" id="star4" name="rating" value="4"/><label class = "full" for="star4" title="Pretty good -  stars"></label>
    <input type="radio" id="star3" name="rating" value="3"/><label class = "full" for="star3" title="Meh -  stars"></label>
    <input type="radio" id="star2" name="rating" value="2"/><label class = "full" for="star2" title="Kinda Bad -  stars"></label>
    <input type="radio" id="star1" name="rating" value="1"/><label class = "full" for="star1" title="Sucks big time -  stars"></label>
  </fieldset>
<br> <br>  
<button class="button"> submit </button> 
         </td>
      </tr>
       
    </table><br><br>
    <br><br>
    
</body>
</html>
