<?php
  require 'connections.php';
    if(isset($_GET['action']) && $_GET['action']=="add"){

        $id=intval($_GET['id']);

        if(isset($_SESSION['cart'][$id])){

            $_SESSION['cart'][$id]['quantity']++;

        }else{

            $sql_s="SELECT * FROM products
                WHERE id_product={$id}";
            $query_s=mysqli_query($koneksi,$sql_s);
            if(mysqli_num_rows($query_s)!=0){
                $row_s=mysqli_fetch_array($query_s);

                $_SESSION['cart'][$row_s['id_product']]=array(
                        "quantity" => 1,

                    );


            }else{

                $message="This product id it's invalid!";

            }

        }

    }

?>
    <h1>Product List</h1>
    <?php
        if(isset($message)){
            echo "<h2>$message</h2>";
        }
    ?>
    <table>
        <tr>
            <th>Name</th>
            <th>Gambar</th>
            <th>Rating</th>
            <th>Action</th>
        </tr>

        <?php

            $sql="SELECT * FROM products";
            $query=mysqli_query($koneksi,$sql);

            while ($row=mysqli_fetch_array($query)) {

        ?>
            <tr>
                <td><?php echo $row['name'] ?></td>
                <td> <img src="<?php echo $row['gambar'] ?>" width="200" height="200"></td>
                <td><form name="rate" method="post" action="rate.php"><img src="star.png" height="23" weight="23"><img src="star.png" height="23" weight="23">
                  <img src="star.png" height="23" weight="23"><img src="star.png" height="23" weight="23">
                  <img src="star.png" height="23" weight="23"><br>
                  <input type="radio" name="rating" value="1">
                  <input type="radio" name="rating2" value="2">
                  <input type="radio" name="rating3" value="3">
                  <input type="radio" name="rating4" value="4">
                  <input type="radio" name="rating5" value="5"><br>
                  <input type="submit" value="simpan"></form>
                </td>
                <td><a href="index.php?page=products&action=add&id=<?php echo $row['id_product'] ?>">Add to cart</a></td>
            </tr>
        <?php

            }

        ?>

    </table>
