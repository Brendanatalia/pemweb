<?php
include "db_connect.php";
$username = $_POST['username'];
$password = $_POST['password'];

if(empty($username)){
echo "<script>alert('Username hasn't filled yet')</script>";
echo "<meta http-equiv='refresh' content='1 url=signup.php'>";
}else
if (empty($password)){
echo "<script>alert('Password hasn't filled yet')</script>";
echo "<meta http-equiv='refresh' content='1 url=signup.php'>";
}else{
$query = "INSERT INTO login (username,password) values ('$username','$password')";
$result = mysqli_query($connection, $query) or die(mysqli_error($connection));
if ($query){
echo "<script>alert('Berhasil Mendaftar')</script>";
echo "<meta http-equiv='refresh' content='1 url=halamanlogin.php'>";
}else{
echo "<script>alert('Gagal Mendaftar')</script>";
echo "<meta http-equiv='refresh' content='1 url=signup.php'>";


}
}
?>
