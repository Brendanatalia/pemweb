<html>
<head>
	<link rel="stylesheet" type="text/css" href="project.css"/>
	<title>Welcome to Ubeaute</title>
</head>
<body>
	<a href="tampildata.php">KEMBALI</a>
	<br/>
	<br/>
	<h3>EDIT DATA BARANG</h3>
 
	<?php
	include 'input2.php';
	$id = $_GET['id'];
	$data = mysqli_query($koneksi,"select * from barang where id='$id'");
	while($d = mysqli_fetch_array($data)){
		?>
		<form method="post" action="update.php">
			<table>
				<tr>			
					<td>Tipe Barang</td>
					<td>
						<input type="text" name="tipe" value="<?php echo $d['tipe']; ?>">
					</td>
				</tr>
				<tr>
					<td>Merk Barang</td>
					<td><input type="text" name="Merk" value="<?php echo $d['Merk']; ?>"></td>
				</tr>
				<tr>
					<td>Nama barang</td>
					<td><input type="text" name="namabarang" value="<?php echo $d['namabarang']; ?>"></td>
				</tr>
				<tr>
					<td></td>
					<td><input type="submit" value="SIMPAN"></td>
				</tr>		
			</table>
		</form>
		<?php 
	}
	?>
 
</body>
</html>
