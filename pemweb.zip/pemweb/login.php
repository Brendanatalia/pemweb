<html>
<head>
  <title>Login</title>
  <link rel="stylesheet" type="text/css" href="project.css"/>
  </head>
  <body>
    <ul>
      <li><a href="project.php">UBEAUTE</a></li>
      <li class="dropdown">
        <a class="drop2">Skincare</a>
        <div class="isidropdown">
          <a href="wardah.php">Wardah</a>
          <a href="#">Viva</a>
          <a href="#">Mustika Ratu</a>
        </div>
      </li>
      <li class="dropdown">
        <a class="drop2">Make Up</a>
        <div class="isidropdown">
          <a href="#">Wardah</a>
          <a href="#">Viva</a>
          <a href="#">Mustika Ratu</a>
        </div>
      </li>
      <li style="float:right"><a href="login.php">Login</a></li>
      <li style="float:right"><img src="keranjang.png" height="30"></li>
    </ul><br><br>
    <center>
		<h1>Login</h1><br><br><br>
    <form method="POST" action="authen_login.php">
    <table>
  <tr><td><center><label for="username"><h3>Username</h3></label></center></td></tr>
  <tr><td><center><input type="text" name="username" id="username" placeholder="Input Username"></center></td></tr>
  <tr><td><center><h3><label for="password">Password</label></h3></center></td></tr>
  <tr><td><center><input type="password" name="password" id="password" placeholder="Input Password"></center></td></tr>
  <tr><td><center><input type="submit" value="Submit"></td></tr></center></table></form>
  <a><b>Don't have any account? Sign Up </b></a><a href="signup.php"><b><u>here</u></b></a>
</center>
	</div>

    </body>
    </html>
