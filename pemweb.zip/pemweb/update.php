<?php 

include 'input2.php';

$id = $_POST['id'];
$tipe = $_POST['tipe'];
$Merk = $_POST['merk'];
$namabarang = $_POST['nama'];
 
mysqli_query($koneksi,"update barang set tipe='$tipe', Merk='$Merk', namabarang='$namabarang' where id='$id'");
 

header("location:tampildata.php");
 
?>
