<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
Halooooo
</body>
</html>




<?php
if(isset($_POST['submit'])){
    $gambar=$_POST["gambar"];
    mysql_connect("localhost", "root", "") OR DIE (mysql_error());
    mysql_select_db ("ubeaute") OR DIE ("Unable to select db".mysql_error());
    $msg="";
    $sql="select * from images where name=$gambar";
    if(mysql_query($sql))
    {
            $res=mysql_query($sql);
            while($row=mysql_fetch_array($res))
            {
                $id=$row['id'];
                $name=$row['name'];
                $image=$row['image'];

                $msg.= '<img src="data:image/jpeg;base6,'.base64_encode($row['image']). ' " />';

            }
    }
    else
     $msg.="Query failed";
?>
<div>
<?php
echo $msg;
}
?>
</div>
