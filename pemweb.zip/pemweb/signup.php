<html>
<head>
  <title>Sign Up</title>
  <link rel="stylesheet" type="text/css" href="project.css"/>
  </head>
  <body>
    <ul>
      <li><a>UBEAUTE</a></li>
      <li class="dropdown">
        <a class="drop2">Skincare</a>
        <div class="isidropdown">
          <a href="#">Wardah</a>
          <a href="#">Viva</a>
          <a href="#">Mustika Ratu</a>
        </div>
      </li>
      <li class="dropdown">
        <a class="drop2">Make Up</a>
        <div class="isidropdown">
          <a href="#">Wardah</a>
          <a href="#">Viva</a>
          <a href="#">Mustika Ratu</a>
        </div>
      </li>
      <li style="float:right"><a href="login.php">Login</a></li>
      <li style="float:right"><img src="keranjang.png" height="30"></li>
    </ul><br><br><center>
		<h1>Sign Up</h1><br>

		<form method="post" action="signup2.php">
      <table>
    <tr><td><label for="username"><h3>Username</h3></label></td></tr>
    <tr><td><input type="text" name="username" id="username" placeholder="Input Username"></td></tr>
    <tr><td><h3><label for="password">Password</label></h3></td></tr>
    <tr><td><input type="password" name="password" id="password" placeholder="Input Password"></td></tr>
    <tr><td><h3><label for="password">Confirm Password</label></h3></td></tr>
    <tr><td><input type="password" name="password" id="password" placeholder="Input Password"></td></tr>
    <tr><td><input type="submit" value="Submit"></td></tr></table>
  </form>
  <b><a>Already have an account? Login </a><a href="login.php"><u>here</u></a></b>
</center>
    </body>
    </html>
